package com.amdocs.SpringBootCustomer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerorderApplicationTests {

	@Test
	void contextLoads() {
		
	}

}
